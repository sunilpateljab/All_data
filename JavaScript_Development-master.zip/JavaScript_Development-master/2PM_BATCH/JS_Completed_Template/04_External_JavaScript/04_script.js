// Add your JavaScript code here
function blue() {
    document.getElementById('green-p').style.color = 'blue';
}
function red() {
    document.getElementById('green-p').style.color = 'red';
}

function facebook() {
    document.getElementById('myImage').setAttribute('src','../img/facebook.jpg');
}
function youtube() {
    document.getElementById('myImage').setAttribute('src','../img/youtube.jpg');
}
